 
<?php $__env->startSection('title','hoanvd02444'); ?>
<?php $__env->startSection('slide-bar'); ?>
o phia tren ne
    ##parent-placeholder-084f900c4668157fac2515aaaec621cb9ca63594##
    hr nam duoi ak
<?php $__env->stopSection(); ?>
<?php $__env->startSection('noidung'); ?>
<h2><?php echo e($name); ?></h2>
<p>day la ten cua toi</p>
<h2>if statement</h2>
<?php if($day=='sunday'): ?>
hom ni la chu nhat
<?php else: ?>
khong phai la chu nhat
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('viewss.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\lib\resources\views/viewss/layout.blade.php ENDPATH**/ ?>