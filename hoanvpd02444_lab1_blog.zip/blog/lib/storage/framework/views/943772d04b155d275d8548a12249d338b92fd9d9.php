;
<?php $__env->startSection('noidung'); ?>
day la trang sub;
<?php $__env->stopSection(); ?>
<?php echo $__env->make('viewss.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/viewss/sub.blade.php ENDPATH**/ ?>