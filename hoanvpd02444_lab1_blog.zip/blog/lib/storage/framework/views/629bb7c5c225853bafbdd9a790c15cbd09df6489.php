<!DOCTYPE html>
<html>
<head>
	<title>lap hoanv- <?php echo $__env->yieldContent('title'); ?></title>
	<style type="text/css">
		.wrapper{
			width: 980px;
			height: auto;
		}
		.header{
			width: auto;
			height: 200px;
			background-color: #f1f1f1;

		}.content{width: auto;height: 500px;background-color: orange;}
		.footer{
			width: auto;height: 280px;background-color: red;
		}
	</style>
</head>
<body>
	<div class="wrapper"></div>
<div class="header">
	<?php $__env->startSection('slide-bar'); ?>
	day la menu
	<?php echo $__env->yieldSection(); ?>
</div>
<div class="content">
	<?php echo $__env->yieldContent('noidung'); ?>
</div>
<div class="footer"></div>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\lib\resources\views/viewss/master.blade.php ENDPATH**/ ?>