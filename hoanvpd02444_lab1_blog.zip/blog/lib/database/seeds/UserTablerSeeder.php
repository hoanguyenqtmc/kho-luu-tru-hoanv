<?php

use Illuminate\Database\Seeder;

class UserTablerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $data=[
          [
           'email'=>'hoanguyenqtmc@gmail.com',
           'password'=>bcrypt('121212'),
           'lever'=>1
          ],
            [
           'email'=>'thuongphan@gmail.com',
           'password'=> bcrypt('121212'),
           'lever'=>1
          ]
        ];
        DB::table('users')->insert($data);
    }
}
