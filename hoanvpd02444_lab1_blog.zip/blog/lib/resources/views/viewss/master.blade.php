<!DOCTYPE html>
<html>
<head>
	<title>lap hoanv- @yield('title')</title>
	<style type="text/css">
		.wrapper{
			width: 980px;
			height: auto;
		}
		.header{
			width: auto;
			height: 200px;
			background-color: #f1f1f1;

		}.content{width: auto;height: 500px;background-color: orange;}
		.footer{
			width: auto;height: 280px;background-color: red;
		}
	</style>
</head>
<body>
	<div class="wrapper"></div>
<div class="header">
	@section('slide-bar')
	day la menu
	@show
</div>
<div class="content">
	@yield('noidung')
</div>
<div class="footer"></div>

</body>
</html>