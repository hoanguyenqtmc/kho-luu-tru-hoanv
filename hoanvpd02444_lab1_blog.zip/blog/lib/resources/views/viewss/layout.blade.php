 @extends('viewss.master')
@section('title','hoanvd02444')
@section('slide-bar')
o phia tren ne
    @parent
    hr nam duoi ak
@stop
@section('noidung')
<h2>{{$name}}</h2>
<p>day la ten cua toi</p>
<h2>if statement</h2>
@if($day=='sunday')
hom ni la chu nhat
@else
khong phai la chu nhat
@endif
@stop