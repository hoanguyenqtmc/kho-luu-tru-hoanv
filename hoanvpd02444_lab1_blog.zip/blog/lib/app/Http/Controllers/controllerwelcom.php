<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controllerwelcom extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
     public function showinfo(){
       return view ('xinchao');
    }
    public function hello(){
    	return view('xinchao');
    }
    public function wellcom(){
    	echo "ho chi minh xau om y";
    	return redirect()->route("hcm");
    }
    public function index(){
        return view('welllcom');
    }
    
}