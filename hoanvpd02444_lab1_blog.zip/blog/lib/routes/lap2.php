<?php

Route::get('welcom','Controllerwelcom@wellcom');
	

?>