<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('xinchao','Controller@showinfo'

);
Route::get('helloword','Controller@hello');
Route::get('hoanv/{masv}', function($masv){
	return "ma so sv:$masv";
});
Route::get('hi/{tenchi}',function($tenchi){
	return "toi ten la:$tenchi";
});
Route::get('/','Controllerwelcom@index');


Route::get('welcom','Controllerwelcom@wellcom');
Route::get('hochiminh',['as'=>'hcm',function(){
return "cho cho minh dep lam";
}]);
Route::get('bangi',function(){
	$tenchi="hoanvpd02444";
return view('home',compact('tenchi'));
});
Route::get('master-goi',function(){
	return view('viewss.layout',array('name'=>'nguyen van hoa','day'=>'sunday'));
});
Route::get('schema/create',function(){
	Schema::create('demo', function($table)
{
	$table->increments('id');
	$table->string('tenmonhoc');
	$table->integer('gia');
	$table->timestamps();
});
});



Route::group(['namespace'=>'Admin'],function(){
    Route::group(['prefix'=>'login'],function(){
        Route::get('/','logintrontroller@getLogin');
        Route::post('/','logintrontroller@postLogin');
       
    });
    Route::get('logout','Homecontroller@getLogout');

     Route::group(['prefix'=>'admin'],function(){
        	Route::get('home','Homecontroller@getHome');
        });

});
